<?php
$servername = "localhost";
$username = "mrro_root";
$password = "root";
$dbname = "mrro_site";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Mr.Robot - Scoreboard</title>
    <link href="assets/css/scoreboardstyle.css" type="text/css" rel="stylesheet">
</head>
<body>

	    <section class="banner">      
        
		<video src="assets/video/bg.mp4"muted loop autoplay></video>
	
		<div class="overlay"></div>

    <div class="scoreboard">
        <table>
            <tr>
                <th>Rank</th>
                <th>Username</th>
                <th>Points</th>
            </tr>
            
            <?php
                $sql = "SELECT CONCAT('#', @row:=@row+1) AS rank, m.username, m.lvl0+m.lvl1+m.lvl2+m.lvl3+m.lvl4+m.lvl5+m.lvl6+m.lvl7+m.lvl8+m.lvl9+m.lvl10 AS Points 
                        FROM tbl_member m, (SELECT @row:=0) b
                        ORDER BY points DESC";
                $result = $conn-> query($sql);
                
                
                if ($result-> num_rows > 0){
                    while ($row = $result-> fetch_assoc()){
                        
                        echo "<tr><td>". $row["rank"] ."</td><td>". $row["username"] ."</td><td>". $row["Points"] ."</td>
                        </tr>";
                    }
                    echo "</table>";
                }
                else{
                    echo "0 result";
               }
                $conn-> close();
                ?>
                
        </table>
            <br>
                <center><a href="home.php">Back to Home</a></center>
                

    </div>
        <div class="footer">
            <p>Mr.Robot™</p>
            <p>Nadeesh | Sandun</p>
        </div>

	 </section>


</body>
</html>
