<?php
use Phppot\flag;

if (! empty($_POST["exect-btn"])) {
    require_once __DIR__ . '/../lib_osi/b.php';
    $flagResponse = $result;

}
?>

<HTML>
<HEAD>
<TITLE>MrRobot_OSInj</TITLE>
<link href="../assets/css/osilevelstyles.css" type="text/css"
	rel="stylesheet" />

<script src="../vendor/jquery/jquery-3.3.1.js" type="text/javascript"></script>


</HEAD>
<BODY>

<section class="banner">
 

<img src="../assets/images/cover.jpg"></img>

<div class="overlay"></div>

                <div class="result-banner">

        	<?php if(!empty($flagResponse)){?>
			    <div class="error-msg"><?php echo $flagResponse["message"]; ?></div>
			<?php }?>                    
                    

                </div>

                <br>
                
    <div class="container">

        <div class="flag">
            <center><h3>Enter the Command</h3></center>
            <br>

           <form name="flag" action="" method="POST" onsubmit="return validateForm()">



            <center>            
            <div class="row">
                <div class="inline-block">
                    <div class="form-label">
                        <span class="required error" id="flag-info"></span>
                    </div>
                    <input type="text" name="command" id="command" placeholder="Enter the command here...">
                </div>    
            </div>

            <div class="row">
                <input type="submit"  value="Execute" id="exect-btn" name="exect-btn">
            </div>
            </center>
            </form>

        </div>
    </div>

<div class="footer">
    <p>Mr.Robot™</p>
    <p>Nadeesh | Sandun</p>
</div>

</section>

<script>
    function validateForm() {
        var valid = true;
        $("#flag").removeClass("error-field");

        var flag = $("#flag").val();

        $("#flag-info").html("").hide();

        if (flag.trim() == "") {
            $("#flag-info").html("required.").css("color", "#ee0000").show();
            $("#flag").addClass("error-field");
            valid = false;
        }

        if (valid == false) {
            $('.error-field').first().focus();
            valid = false;
        }
        return valid;
    }
</script>

<script>
/* Set the width of the sidebar to 250px and the left margin of the page content to 250px */
function openNav() {
  document.getElementById("mySidebar").style.width = "200px";
  document.getElementById("main").style.marginLeft = "200px";
}

/* Set the width of the sidebar to 0 and the left margin of the page content to 0 */
function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft = "0";
}    
</script>


</BODY>
</HTML>
